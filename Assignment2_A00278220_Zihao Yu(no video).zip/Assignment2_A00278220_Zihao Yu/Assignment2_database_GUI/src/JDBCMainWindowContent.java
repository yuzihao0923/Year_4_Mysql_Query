import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.Border;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

@SuppressWarnings("serial")
public class JDBCMainWindowContent extends JInternalFrame implements ActionListener
{	
	String cmd = null;

	// DB Connectivity Attributes
	private Connection con = null;
	private Statement stmt = null;
	private ResultSet rs = null;

	private Container content;

	private JPanel seasonPanel;
	private JPanel exportButtonPanel;
	//private JPanel exportConceptDataPanel;
	private JScrollPane dbContentsPanel;

	private Border lineBorder;

	private JLabel IDLabel=new JLabel("Player ID:                 ");
	private JLabel NameLabel=new JLabel("Player Name:               ");
	private JLabel NumberLabel=new JLabel("Player Number:      ");
	private JLabel GPLabel=new JLabel("GP:      ");
	private JLabel MINLabel=new JLabel("MIN:      ");
	private JLabel PTSLabel=new JLabel("PTS:      ");
	private JLabel FGMLabel=new JLabel("FGM:      ");
	private JLabel FGALabel=new JLabel("FGA:      ");
	private JLabel FGperLabel=new JLabel("FG_per:      ");
	private JLabel PMLabel=new JLabel("3PM:      ");
	private JLabel PALabel=new JLabel("3PA:      ");
	private JLabel PLabel=new JLabel("3P_per:      `");
	private JLabel FTMLabel=new JLabel("FTM:      ");
	private JLabel FTALabel=new JLabel("FTA:      ");
	private JLabel FTLabel=new JLabel("FT_per:      ");
	private JLabel OREBLabel=new JLabel("OREB:      ");
	private JLabel DREBLabel=new JLabel("DREB:      ");
	private JLabel REBLabel=new JLabel("REB:      ");
	private JLabel ASTLabel=new JLabel("AST:      ");
	private JLabel TOVLabel=new JLabel("TOV:      ");
	private JLabel STLLabel=new JLabel("STL:      ");
	private JLabel BLKLabel=new JLabel("BLK:      ");
	private JLabel PFLabel=new JLabel("PF:      ");
	private JLabel PNLabel=new JLabel("Positive_Negative:      ");
	

	private JTextField IDTF= new JTextField(10);
	private JTextField NameTF=new JTextField(50);
	private JTextField NumberTF=new JTextField(10);
	private JTextField GPTF=new JTextField(10);
	private JTextField MINTF=new JTextField(10);
	private JTextField PTSTF=new JTextField(10);
	private JTextField FGMTF=new JTextField(10);
	private JTextField FGATF=new JTextField(10);
	private JTextField FGperTF=new JTextField(10);
	private JTextField PMTF=new JTextField(10);
	private JTextField PATF=new JTextField(10);
	private JTextField PTF=new JTextField(10);
	private JTextField FTMTF=new JTextField(10);
	private JTextField FTATF=new JTextField(10);
	private JTextField FTLTF=new JTextField(10);
	private JTextField OREBTF=new JTextField(10);
	private JTextField DREBTF=new JTextField(10);
	private JTextField REBTF=new JTextField(10);
	private JTextField ASTTF=new JTextField(10);
	private JTextField TOVTF=new JTextField(10);
	private JTextField STLTF=new JTextField(10);
	private JTextField BLKTF=new JTextField(10);
	private JTextField PFTF=new JTextField(10);
	private JTextField PNTF=new JTextField(10);




	private static QueryTableModel TableModel = new QueryTableModel();
	//Add the models to JTabels
	private JTable TableofDBContents=new JTable(TableModel);
	//Buttons for inserting, and updating members
	//also a clear button to clear details panel
	private JButton updateButton = new JButton("Update");
	private JButton insertButton = new JButton("Insert");
	private JButton exportButton  = new JButton("Export");
	private JButton deleteButton  = new JButton("Delete");
	private JButton clearButton  = new JButton("Clear");

	private JButton  University = new JButton("Seach player's Graduated University: ");
	private JTextField UniversityTF  = new JTextField(12);
	private JButton avgAge  = new JButton("Average Of Column: ");
	private JTextField avgAgeTF  = new JTextField(12);
	private JButton ListPositive_negative_below_0  = new JButton("ListPositive_negative < 0");
	private JButton ListDetails  = new JButton("List Player's All Detail");



	public JDBCMainWindowContent( String aTitle)
	{	
		//setting up the GUI
		super(aTitle, false,false,false,false);
		setEnabled(true);

		initiate_db_conn();
		//add the 'main' panel to the Internal Frame
		content=getContentPane();
		content.setLayout(null);
		content.setBackground(Color.lightGray);
		lineBorder = BorderFactory.createEtchedBorder(15, Color.red, Color.black);

		//setup details panel and add the components to it
		seasonPanel=new JPanel();
		seasonPanel.setLayout(new GridLayout(25,1));
		seasonPanel.setBackground(Color.lightGray);
		seasonPanel.setBorder(BorderFactory.createTitledBorder(lineBorder, "CRUD Actions"));

		seasonPanel.add(IDLabel);			
		seasonPanel.add(IDTF);
		seasonPanel.add(NameLabel);		
		seasonPanel.add(NameTF);
		seasonPanel.add(NumberLabel);		
		seasonPanel.add(NumberTF);
		seasonPanel.add(GPLabel);	
		seasonPanel.add(GPTF);
		seasonPanel.add(MINLabel);		
		seasonPanel.add(MINTF);
		seasonPanel.add(PTSLabel);
		seasonPanel.add(PTSTF);
		seasonPanel.add(FGMLabel);
		seasonPanel.add(FGMTF);
		seasonPanel.add(FGALabel);
		seasonPanel.add(FGATF);
		seasonPanel.add(FGperLabel);
		seasonPanel.add(FGperTF);
		seasonPanel.add(PMLabel);
		seasonPanel.add(PMTF);
		seasonPanel.add(PALabel);
		seasonPanel.add(PATF);
		seasonPanel.add(PLabel);
		seasonPanel.add(PTF);
		seasonPanel.add(FTMLabel);
		seasonPanel.add(FTMTF);
		seasonPanel.add(FTALabel);
		seasonPanel.add(FTATF);
		seasonPanel.add(FTLabel);
		seasonPanel.add(FTLTF);
		seasonPanel.add(OREBLabel);
		seasonPanel.add(OREBTF);
		seasonPanel.add(DREBLabel);
		seasonPanel.add(DREBTF);
		seasonPanel.add(REBLabel);
		seasonPanel.add(REBTF);
		seasonPanel.add(ASTLabel);
		seasonPanel.add(ASTTF);
		seasonPanel.add(TOVLabel);
		seasonPanel.add(TOVTF);
		seasonPanel.add(STLLabel);
		seasonPanel.add(STLTF);
		seasonPanel.add(BLKLabel);
		seasonPanel.add(BLKTF);
		seasonPanel.add(PFLabel);
		seasonPanel.add(PFTF);
		seasonPanel.add(PNLabel);
		seasonPanel.add(PNTF);

		//setup details panel and add the components to it
		exportButtonPanel=new JPanel();
		exportButtonPanel.setLayout(new GridLayout(3,2));
		exportButtonPanel.setBackground(Color.lightGray);
		exportButtonPanel.setBorder(BorderFactory.createTitledBorder(lineBorder, "Export Data"));
		exportButtonPanel.add(University);
		exportButtonPanel.add(UniversityTF);
		exportButtonPanel.add(avgAge);
		exportButtonPanel.add(avgAgeTF);
		exportButtonPanel.add(ListPositive_negative_below_0);
		exportButtonPanel.add(ListDetails);
		exportButtonPanel.setSize(500, 200);
		exportButtonPanel.setLocation(3, 300);
		content.add(exportButtonPanel);

		insertButton.setSize(100, 30);
		updateButton.setSize(100, 30);
		exportButton.setSize (100, 30);
		deleteButton.setSize (100, 30);
		clearButton.setSize (100, 30);

		insertButton.setLocation(370, 10);
		updateButton.setLocation(370, 110);
		exportButton.setLocation (370, 160);
		deleteButton.setLocation (370, 60);
		clearButton.setLocation (370, 210);

		insertButton.addActionListener(this);
		updateButton.addActionListener(this);
		exportButton.addActionListener(this);
		deleteButton.addActionListener(this);
		clearButton.addActionListener(this);

		this.ListPositive_negative_below_0.addActionListener(this);
		this.University.addActionListener(this);
		this.avgAge.addActionListener(this);
		this.ListDetails.addActionListener(this);


		content.add(insertButton);
		content.add(updateButton);
		content.add(exportButton);
		content.add(deleteButton);
		content.add(clearButton);


		TableofDBContents.setPreferredScrollableViewportSize(new Dimension(900, 300));

		dbContentsPanel=new JScrollPane(TableofDBContents,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		dbContentsPanel.setBackground(Color.lightGray);
		dbContentsPanel.setBorder(BorderFactory.createTitledBorder(lineBorder,"Database Content"));

		seasonPanel.setSize(360, 325);
		seasonPanel.setLocation(3,0);
		dbContentsPanel.setSize(900, 300);
		dbContentsPanel.setLocation(470, 0);
		
		content.add(seasonPanel);
		content.add(dbContentsPanel);
		
		
		
		setSize(5000,2000);
		setVisible(true);

		TableModel.refreshFromDB(stmt);
	}

	public void initiate_db_conn()
	{
		try
		{
			// Load the JConnector Driver
			Class.forName("com.mysql.jdbc.Driver");
			// Specify the DB Name
			String url="jdbc:mysql://localhost:3306/season2021_2022";
			// Connect to DB using DB URL, Username and password
			con = DriverManager.getConnection(url, "root", "123456");
			//Create a generic statement which is passed to the TestInternalFrame1
			stmt = con.createStatement();
			
			//rs = stmt.executeQuery("Select * from playerdata");
		}
		catch(Exception e)
		{
			System.out.println("Error: Failed to connect to database\n"+e.getMessage());
		}
	}

	//event handling 
	public void actionPerformed(ActionEvent e)
	{
		Object target=e.getSource();
		if (target == clearButton)
		{
			IDTF.setText("");
			NameTF.setText("");
			NumberTF.setText("");
			GPTF.setText("");
			MINTF.setText("");
			PTSTF.setText("");
			FGMTF.setText("");
			FGATF.setText("");
			FGperTF.setText("");
			PMTF.setText("");
			PATF.setText("");
			PTF.setText("");
			FTMTF.setText("");
			FTATF.setText("");
			FTLTF.setText("");
			OREBTF.setText("");
			DREBTF.setText("");
			REBTF.setText("");
			ASTTF.setText("");
			TOVTF.setText("");
			STLTF.setText("");
			BLKTF.setText("");
			PFTF.setText("");
			PNTF.setText("");
			

		}

		if (target == insertButton)
		{		 
			try
			{
				String updateTemp ="INSERT INTO playerdata VALUES("+IDTF.getText()+",'"+NameTF.getText()+"',"+NumberTF.getText()+","+GPTF.getText()+","
				+MINTF.getText()+","+PTSTF.getText()+","+FGMTF.getText()+","+FGATF.getText()+","
				+FGperTF.getText()+","+PMTF.getText()+","+PATF.getText()+","+PTF.getText()+","+FTMTF.getText()+","
				+FTATF.getText()+","+FTLTF.getText()+","+OREBTF.getText()+","+DREBTF.getText()+","
				+REBTF.getText()+","+ASTTF.getText()+","+TOVTF.getText()+","+STLTF.getText()+","+BLKTF.getText()+","
				+PFTF.getText()+","+PNTF.getText()+");";

				stmt.executeUpdate(updateTemp);

			}
			catch (SQLException sqle)
			{
				System.err.println("Error with  insert:\n"+sqle.toString());
			}
			finally
			{
				TableModel.refreshFromDB(stmt);
			}
		}
		
		if (target == deleteButton)
		{

			try
			{
				String updateTemp ="DELETE FROM playerdata WHERE player_id = "+IDTF.getText()+";"; 
				stmt.executeUpdate(updateTemp);

			}
			catch (SQLException sqle)
			{
				System.err.println("Error with delete:\n"+sqle.toString());
			}
			finally
			{
				TableModel.refreshFromDB(stmt);
			}
		}

		
		if (target == updateButton)
		{	 	
			try
			{ 			
				String updateTemp ="UPDATE playerdata SET " +
				"player_id = "+IDTF.getText()+
				", player_name = '"+NameTF.getText()+
				"', player_number = "+NumberTF.getText()+
				", GP = "+GPTF.getText()+
				", MIN = "+MINTF.getText()+
				", PTS = "+PTSTF.getText()+
				", FGM = "+FGMTF.getText()+
				", FGA = "+FGATF.getText()+
				", FG_per ="+FGperTF.getText()+
				", 3PM = "+PMTF.getText()+
				", 3PA = "+PATF.getText()+
				", 3P_per = "+PTF.getText()+
				", FTM = "+FTMTF.getText()+
				", FTA = "+FTATF.getText()+
				", FT_per = "+FTLTF.getText()+
				", OREB = "+OREBTF.getText()+
				", DREB = "+DREBTF.getText()+
				", REB = "+REBTF.getText()+
				", AST = "+ASTTF.getText()+
				", TOV = "+TOVTF.getText()+
				", STL = "+STLTF.getText()+
				", BLK = "+BLKTF.getText()+
				", PF = "+PFTF.getText()+
				", Positive_negative = "+PNTF.getText()+
				"where player_id = "+IDTF.getText();


				stmt.executeUpdate(updateTemp);
				//these lines do nothing but the table updates when we access the db.
				rs = stmt.executeQuery("SELECT * from playerdata ");
				rs.next();
				rs.close();	
			}
			catch (SQLException sqle){
				System.err.println("Error with  update:\n"+sqle.toString());
			}
			finally{
				TableModel.refreshFromDB(stmt);
			}
		}
		
		
		if (target == exportButton)
		{	 	
			try
			{ 			
				String output ="player_id = "+IDTF.getText()+
				", player_name = '"+NameTF.getText()+
				"', player_number = "+NumberTF.getText()+
				", GP = "+GPTF.getText()+
				", MIN = "+MINTF.getText()+
				", PTS = "+PTSTF.getText()+
				", FGM = "+FGMTF.getText()+
				", FGA = "+FGATF.getText()+
				", FG_per ="+FGperTF.getText()+
				", 3PM = "+PMTF.getText()+
				", 3PA = "+PATF.getText()+
				", 3P_per = "+PTF.getText()+
				", FTM = "+FTMTF.getText()+
				", FTA = "+FTATF.getText()+
				", FT_per = "+FTLTF.getText()+
				", OREB = "+OREBTF.getText()+
				", DREB = "+DREBTF.getText()+
				", REB = "+REBTF.getText()+
				", AST = "+ASTTF.getText()+
				", TOV = "+TOVTF.getText()+
				", STL = "+STLTF.getText()+
				", BLK = "+BLKTF.getText()+
				", PF = "+PFTF.getText()+
				", Positive_negative = "+PNTF.getText()+"";
				


				System.out.println(output);
				//these lines do nothing but the table updates when we access the db.
				rs = stmt.executeQuery("SELECT * from playerdata ");
				rs.next();
				rs.close();	
			}
			catch (SQLException sqle){
				System.err.println("Error with  update:\n"+sqle.toString());
			}
			finally{
				TableModel.refreshFromDB(stmt);
			}
		}

//		/////////////////////////////////////////////////////////////////////////////////////
//		//I have only added functionality of 2 of the button on the lower right of the template
//		///////////////////////////////////////////////////////////////////////////////////
//
		if(target == this.ListPositive_negative_below_0){

			cmd = "select * from playerdata where Positive_negative < 0;";

			try{					
				rs= stmt.executeQuery(cmd); 	
				writeToFile(rs);
			}
			catch(Exception e1){e1.printStackTrace();}
			}

		

		if(target == this.University){
			String UniversityName = this.UniversityTF.getText();

			cmd = "select playernumber.player_name, player_university from season2021_2022.playernumber inner join season2021_2022.playerdata on playernumber.player_id = playerdata.player_id where playernumber.player_name = '" +UniversityName+ "';";

			System.out.println(cmd);
			try{					
				rs= stmt.executeQuery(cmd); 	
				writeToFile(rs);
			}
			catch(Exception e1){e1.printStackTrace();}

		} 
	
	
	
		if(target == this.avgAge){
		
		String columnName = this.avgAgeTF.getText();
		cmd = "SELECT avg(" + columnName + ") as 'Average of Column*' FROM season2021_2022.playerdata";
		
		System.out.println(cmd);
		
		try{					
			rs= stmt.executeQuery(cmd);
			
			writeToFile(rs);
			
			
		}
		catch(Exception e1){e1.printStackTrace();}
		}
		
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	if(target == this.ListDetails){

		String UniversityName = this.UniversityTF.getText();
		cmd = "select playerdata.player_name, playernumber.player_university, MIN, PTS, FG_per, 3P_per, FT_per, REB, AST, Positive_negative from season2021_2022.playerdata inner join season2021_2022.playernumber on playerdata.player_id = playernumber.player_id where playerdata.player_name = '"   +UniversityName+ "';";

		try{					
			rs= stmt.executeQuery(cmd); 	
			writeToFile(rs);
		}
		catch(Exception e1){e1.printStackTrace();}
		}
	}
//	///////////////////////////////////////////////////////////////////////////
//
	private void writeToFile(ResultSet rs){
		try{
			System.out.println("In writeToFile");
			FileWriter outputFile = new FileWriter("output.csv");
			PrintWriter printWriter = new PrintWriter(outputFile);
			ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
			int numColumns = rsmd.getColumnCount();

			for(int i=0;i<numColumns;i++){
				printWriter.print(rsmd.getColumnLabel(i+1)+",");
			}
			printWriter.print("\n");
			while(rs.next()){
				for(int i=0;i<numColumns;i++){
					printWriter.print(rs.getString(i+1)+",");
				}
				printWriter.print("\n");
				printWriter.flush();
			}
			printWriter.close();
		}
		catch(Exception e){e.printStackTrace();}
		}
}
